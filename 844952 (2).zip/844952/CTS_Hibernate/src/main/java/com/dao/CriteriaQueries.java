package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.pojo.Emp_Pojo;

public class CriteriaQueries {

	public static void main(String[] args) {
		SessionFactory sessionFactory=new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory();
		Session s=sessionFactory.openSession();
		
		Transaction t=s.beginTransaction();
		Criteria cr=s.createCriteria(Emp_Pojo.class);
		//Add restriction
		//cr.add(Restrictions.gt("salary1",50000.00F));
		cr.add(Restrictions.between("salary1",25000.00F,48000.00f));
		List emps=cr.list();
		List<Emp_Pojo> l4=(List<Emp_Pojo>)cr.list();
		for(Emp_Pojo e:l4)
		{
			System.out.println("First criteria "+e.getEmpno1()+" "+e.getEmpname());
		}
		//Projections-- average,maximum,minimum
		//to get total salary
		Criteria cr1=s.createCriteria(Emp_Pojo.class);
		cr1.setProjection(Projections.sum("salary1"));
		List sum=cr1.list();
		System.out.println("Total salary:"+sum.get(0));
		System.out.println("from Emp_Pojo");
	}

}
