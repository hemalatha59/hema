package com.dao;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Emp_Pojo;

public class Emp_DAOMain {

	public static void main(String[] args) {
		SessionFactory sessionFactory=new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		//start a transaction
		Transaction tx=session.beginTransaction();
		Emp_Pojo e1=new Emp_Pojo();
		Scanner sc=new Scanner(System.in);

		System.out.println("Eno:");
		int eno1=sc.nextInt();
		System.out.println("Ename:");
		String name1=sc.next();
		System.out.println("Salary:");
		float salary=sc.nextFloat();
		e1.setEmpno1(eno1);
		e1.setEmpname(name1);
		e1.setSalary1(salary);
		//upto emp_pojo is transient state
		//persist()=====insert into tablename  values
		session.persist(e1);//persistent state or saving Pojo object
		System.out.println("*****Inserted*****");
		tx.commit();
	}

}
