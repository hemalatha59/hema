package com.dao;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.pojo.Emp_Pojo;

public class EmpViewMain {

	public static void main(String[] args) {
		SessionFactory sessionFactory=new Configuration().configure("cts_hibernate.cfg.xml").buildSessionFactory();
		Session session=sessionFactory.openSession();
		/*
		 * HQL-Hibernate query language
		 * HQL uses  class name instead of table name
		 * and property names instead of column name
		 */
		//String query1="select * from Emp_Pojo";//error
		
		//String query2="select Empno1,Empname1,salary1 from Emp_Pojo";//valid
		//No table name only pojo class name
		
		String query1="From Emp_Pojo";
		Query query4=session.createQuery(query1);
		List<Emp_Pojo> l=(List<Emp_Pojo>)query4.list();//ResultSet
		for(Emp_Pojo e:l)
		{
			System.out.println(e.getEmpno1()+" "+e.getEmpname()+" "+e.getSalary1());
		}
		
		String Sql_query="select max(e1.salary1) from Emp_Pojo e1";
		query4=session.createQuery(Sql_query);
		List l1=query4.list();
		System.out.println("Max Salary:"+l1.get(0));
		
		Query q5=session.createQuery("from Emp_Pojo where Empname='Hema'");
		List l3=q5.list();
		Emp_Pojo obj1=(Emp_Pojo)l3.get(0);
		System.out.println("Hema Slary:"+obj1.getSalary1());
		
		//Parameterized queries
		//Positional Parameters
		//String q="from Emp_Pojo where Empno1=?";
		
		String q="from Emp_Pojo where Empno1=:a";
		query4=session.createQuery(q);
		System.out.println("Enter the ENO");
		Scanner sc=new Scanner(System.in);
		int eno11=sc.nextInt();
		query4.setInteger("a", eno11);
		List l2=query4.list();
		Emp_Pojo obj21=(Emp_Pojo)l2.get(0);
		System.out.println("Name & Salary:"+ obj21.getEmpname()+" "+obj21.getSalary1());
		session.close();
		
	}

}
