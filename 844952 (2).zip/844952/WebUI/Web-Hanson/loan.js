function avail(){
	var limit=100000;
	var amount=50000;
	if(amount<limit)
	{

		document.writeln("loan is available");
	}
	else
	{
		document.writeln("Not available");
	}
}