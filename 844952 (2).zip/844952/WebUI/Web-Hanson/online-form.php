<!DOCTYPE html>
<html>

<body>
	<h2>The form has submitted successfully</h2>
</body>
</html>