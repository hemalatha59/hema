create database student;
use student;
create table stud(s_id int not null,
name varchar(100) not null,
city varchar(100) not null,
primary key(s_id));
insert into stud values(1,'suma','chennai');
insert into stud values(2,'shivani','Chennai');
insert into stud values(3,'Ravi','Bengalore');
insert into stud values(4,'Dhoni','Hyderabad');
insert into stud values(5,'honey','Nandyal');
insert into stud values(6,'Harish','Chennai');
create table course(c_id int not null,
c_name varchar(100) not null, 
fees int not null,
primary key(c_id));
insert into course values(1,'C',500);
insert into course values(2,'Java',1500);
insert into course values(3,'Sql',1200);
insert into course values(4,'C++',800);
insert into course values(5,'Python',2000);
select name,c_name,fees 
from stud
right outer join course 
on stud.s_id=course.c_id;

select * from stud;
select * from course;