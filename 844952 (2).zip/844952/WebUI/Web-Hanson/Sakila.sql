use sakila;
select * from actor;
select * from actor where first_name='Scarlett';
select * from actor where last_name='Johansson';
select count(distinct last_name) from actor; 
select distinct last_name from actor;
select last_name ,count(last_name)
from actor 
group by last_name
having count(last_name)>1;  
select distinct inventory_id
from rental;
desc rental;
select avg(length) as 'running_time' from film;
insert into rental(rental_date,inventory_id,customer_id,staff_id) values(now(),1,1,1);
insert into actor values(500,'Mary','Smith', now());
select * from film;
select category.name, avg(length) as 'running_time' from film,category group by category_id;
use sakila;
select first_name,count(actor_id)
from actor
join film_actor
using(actor_id) group by actor_id order by count(actor_id);
select * from film;