create database banking;
use banking;
create table bank_details(
b_id int not null,
b_name varchar(100) not null,
city varchar(100) not null,
b_manager varchar(100) not null,
primary key(b_id)
);
describe bank_details;
alter table bank_details
add phone int not null;
describe bank_details;
alter table bank_details
add b_code int not null
after b_id,
add loan_limit int not null;
describe bank_details;
alter table bank_details
change column phone Mobile int not null; 
alter table bank_details
rename to branch_details;
describe branch_details;
/* truncate table branch_details; */
/* drop table branch_details; */
create table customer_details(
c_id int not null, 
c_fname varchar(100) not null, 
c_lname varchar(100) not null, 
c_address varchar(200) not null, 
c_mobile int not null,
primary key (c_id));
describe branch_details;
insert into branch_details values(
1, 101, 'Navalur', 'chennai', 'Manohar', 9967542393, 100000); 
alter table branch_details
modify Mobile bigint not null;
alter table branch_details
modify b_code varchar(100) not null;
insert into branch_details values(
1, 'CH101', 'Navalur', 'Chennai', 'Manohar', 9967542393, 100000);
insert into branch_details values(
2, 'CH102', 'Kelambakkam', 'Chennai', 'Janaki', 9967548906, 200000);
insert into branch_details values(
3, 'BLR103', 'Hebbal', 'Bengalore', 'Kalyan', 9067542393, 300000);
insert into branch_details values(
4, 'BLR104', 'Silkboard', 'Bengalore', 'Hema', 9398884873, 400000);
insert into branch_details values(
5, 'HYD105', 'HitechCity', 'Hyderabad', 'Shivani', 939004873, 600000);
select * from branch_details;
describe customer_details;
insert into customer_details values(6, 'Lohitha', 'Chandu', 'Bengalore', 9006743218);
insert into customer_details values(7, 'Madhu', 'Reddy', 'Chennai', 9553293788);
insert into customer_details values(8, 'Swarna', 'Chandu', 'Bengalore', 9000049967);
insert into customer_details values(9, 'Ravi', 'Chandu', 'Bengalore', 7092674516);
insert into customer_details values(10, 'Geetha', 'Ediga', 'Hyderabad', 8889012345);
alter table customer_details
modify c_mobile bigint not null;
select * from customer_details;
update customer_details 
set c_lname="Reddy"
where c_id=3;
select c_fname, c_lname from customer_details;
insert into customer_details values(1, 'Mani', 'Chndu', 'Hyderabad', 9036743218);
insert into customer_details values(2, 'Madhusudhan', 'Pagidala', 'Chennai', 9563293788);
insert into customer_details values(3, 'hema', 'Reddy', 'Bengalore', 9003449967);
insert into customer_details values(4, 'Poojith', 'Kodavaluru', 'Chennai', 7098674516);
insert into customer_details values(5, 'Afreen', 'Shaik', 'Hebbal', 8879012345);
use banking;
alter table customer_details 
add age int not null after c_lname;
insert into customer_details values(1, 'Mani', 'Chndu', 25,'Hyderabad', 9036743218);
insert into customer_details values(2, 'Madhusudhan', 60,'Pagidala', 'Chennai', 9563293788);
insert into customer_details values(3, 'hema', 'Reddy', 23,'Bengalore', 9003449967);
insert into customer_details values(4, 'Poojith', 21,'Kodavaluru', 'Chennai', 7098674516);
insert into customer_details values(5, 'Afreen', 22, 'Shaik', 'Hebbal', 8879012345);
insert into customer_details values(11, 'Lohitha', 'Chandu', 20,'Bengalore', 9006743218);
insert into customer_details values(7, 'Madhu', 'Reddy',57,'Chennai', 9553293788);
insert into customer_details values(8, 'Swarna', 'Chandu', 26,'Bengalore', 9000049967);
insert into customer_details values(9, 'Ravi', 'Chandu',32,'Bengalore', 7092674516);
insert into customer_details values(10, 'Geetha', 'Ediga', 22,'Hyderabad', 8889012345);
select * from customer_details;
alter table customer_details
drop column age;
select distinct c_address,c_fname from customer_details; 
select * from customer_details order by c_fname ASC;
select * from customer_details order by c_address asc, c_id desc;
select c_address, count(*)
from customer_details;
select * from customer_details
group by c_address;
select c_fname, count(*)
from customer_details group by c_fname;
select * from customer_details;
alter table customer_details 
add c_loan bigint after c_lname;
update customer_details set c_loan=100000 where c_id=1;
update customer_details set c_loan=50000 where c_id=2;
update customer_details set c_loan=60000 where c_id=3;
update customer_details set c_loan=5000 where c_id=5;
update customer_details set c_loan=2000 where c_id=6;
update customer_details set c_loan=200000 where c_id=7;
update customer_details set c_loan=80000 where c_id=8;
update customer_details set c_loan=20000 where c_id=9;
update customer_details set c_loan=10000 where c_id=10;
select sum(c_loan) as total_loan from customer_details; 
select c_fname, max(c_loan) as max_loan from customer_details;
select c_fname, sum(c_loan) as "c_loan" from customer_details
group by c_fname 
having sum(c_loan)>100000; 
select c_fname, c_address
from customer_details where c_address like 'Hyd%';
select c_fname, c_address
from customer_details where c_address like 'Hyd___bad';
select c_fname, c_address
from customer_details where c_address like '_hennai';
select c_fname, c_address
from customer_details where c_address not like 'Hyd%';
select * from customer_details 
where c_fname not in('Swarna','Lohitha','Madhu');
select * from customer_details 
where c_id between 1 and 5;
alter table customer_details
add c_dob date not null 
after c_loan;
update customer_details set c_dob='1991-12-15' where c_id=1;
update customer_details set c_dob='1992-12-15' where c_id=2;
update customer_details set c_dob='1993-12-15' where c_id=3;
update customer_details set c_dob='1994-12-15' where c_id=4;
update customer_details set c_dob='1995-12-15' where c_id=5;
update customer_details set c_dob='1996-12-15' where c_id=6;
update customer_details set c_dob='1997-12-15' where c_id=7;
update customer_details set c_dob='1998-12-15' where c_id=8;
update customer_details set c_dob='1999-12-15' where c_id=9;
update customer_details set c_dob='1990-12-15' where c_id=10;
select * from customer_details where c_dob between cast ('1991-12-15' as date) and cast ('1991-12-16' as date);