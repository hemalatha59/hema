create database EmployeeAssessment;
use EmployeeAssessment;
create table Emp_details(
e_id int not null,
e_name varchar(100) not null,
designation varchar(100) not null,
salary varchar(100) not null,
doj date not null,
dob date not null,
age int not null,
primary key(e_id)
);
create table Dept_details(d_id int not null, d_name varchar(100) not null);
create table Project(p_id int not null, p_name varchar(100) not null, primary key(p_id));
drop table Dept_details;
create table Dept_details(d_id int not null, d_name varchar(100) not null, primary key(d_id));
drop table Emp_details;
create table Emp_details(
e_id int not null,
e_name varchar(100) not null,
designation varchar(100) not null,
salary varchar(100) not null,
doj date not null,
dob date not null,
age int not null,
primary key(e_id)
);
desc Emp_details;
desc Dept_details;
desc Project;
drop table Emp_details;
create table emp_details(
e_id int not null,
e_name varchar(100) not null,
designation varchar(100) not null,
salary varchar(100) not null,
doj date not null,
dob date not null,
age int not null,
primary key(e_id),
d_id int not null, foreign key(d_id) references Dept_details(d_id)
);
desc emp_details;
describe emp_details;
drop table Emp_details;
create table emp_details(
e_id int not null,
e_name varchar(100) not null,
dob date not null,
doj date not null,
designation varchar(100) not null,
salary varchar(100) not null,
primary key(e_id),
d_id varchar(100) not null, foreign key(d_id) references Dept_details(d_id)
);
alter table Dept_details
modify d_id varchar(100) not null;
alter table Project
modify p_id varchar(100) not null;
describe Project;
alter table Project drop column d_name;
alter table emp_details
add d_name varchar(100) not null;
insert into Dept_details values('1001','LKM');
insert into Dept_details values('1002','Java');
insert into Dept_details values('1003','.NET');

insert into Project values('P1','Retail');
insert into Project values('P2','Insurence');
insert into Project values('P3','Resources');
insert into Project values('P4','Banking');
insert into Project values('P5','Internal Project');


insert into emp_details values(7001,'Cynthya','1975-05-12','1997-02-14', 'CEO', 800000,'1001','Java');
insert into emp_details values(7002,'Mario','1976-02-14','1998-04-16', 'MD', 500000,'1002','Java');
insert into emp_details values(7003,'Jacob','1976-05-16','1998-05-16', 'MD', 400000,'1003','.NET');
insert into emp_details values(7004,'Lucy','1978-05-15','2000-07-15', 'MD', 420000,'1001','LKM');
insert into emp_details values(7005,'Amy','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');
insert into emp_details values(7006,'Frank','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');
insert into emp_details values(7007,'Phil','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');
insert into emp_details values(7008,'Arnold','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');
insert into emp_details values(7009,'Jack','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');
insert into emp_details values(7010,'Justin','1975-05-12','1997-02-14', 'CEO', 800000.00,'1001','Java');