function validateForm()
{
	var name=document.form1.name.value;
	var pwd=document.form1.pwd.value;
	if (name==null || name=="")
	{  
	  	alert("Name can't be blank");  
	  	return false;  
	}
	else if(pwd.length<8)
	{  
	  	alert("Password must be at least 6 characters long.");  
	  	return false;  
  	}  
}  

