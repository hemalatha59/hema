package com.example.geometry;

import com.example.shapes.*;

public class Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
