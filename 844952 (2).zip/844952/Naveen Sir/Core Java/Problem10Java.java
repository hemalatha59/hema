import java.util.*;
class Problem10java
{
 	public static void main(String args[])
	{
		
		int prev=0,curr=1,next=1,i=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of n");
		int n=sc.nextInt();
		
		while(i<n)
		{
			
			prev=curr;
			curr=next;
			next=prev+curr;
			++i;
			
				
		}
	System.out.println(curr-prev);
			
	}
}
