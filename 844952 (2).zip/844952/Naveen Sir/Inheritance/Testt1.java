//3,4
abstract interface Bendable {
	 final int x = 2009;

	void method1();
		

	public static class Angle {}

}
class Testt1
{
 	public static void main(String args[])
	{
		//void method1(){
		//System.out.println(x);}
	}
}


/*	abstract interface Bendable {
		 final int x = 2009;

		void method1();
			

		public static class Angle {}

	}
	public static void main(String args[])
		{
			//void method1(){
			System.out.println("Hello");
		}
	
		
}*/
