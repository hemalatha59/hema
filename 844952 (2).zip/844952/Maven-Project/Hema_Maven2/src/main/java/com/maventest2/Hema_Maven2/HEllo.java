package com.maventest2.Hema_Maven2;

public class HEllo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("HEllo Maven");
	}

}
