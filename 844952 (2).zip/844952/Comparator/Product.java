package Classes;

import java.util.Date;

class Product{
	int id;
	String productName;
	Double price;
	Date dom;
	public Product(int id, String productName, Double price, Date dom)
	{
		this.id=id;
		this.productName=productName;
		this.price=price;
		this.dom=dom;
	}
	public String toString()
	{
		return this.id+" "+this.productName+" "+this.price+" "+this.dom;
	}
}

