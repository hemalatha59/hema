package Classes;

import java.util.Comparator;

public class NameComparator implements Comparator<Product>{

	@Override
	public int compare(Product p1, Product p2) {
		// TODO Auto-generated method stub
		
		return p1.productName.compareTo(p2.productName);
	}


}
