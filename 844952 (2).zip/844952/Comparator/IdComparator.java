package Classes;

import java.util.Comparator;

public class IdComparator implements Comparator<Product> {
	@Override
	public int compare(Product o1,Product o2)
	{
		int res=0;
		if(o1.id<o2.id)
		{
			res=-1;
		}
		else if(o1.id>o2.id)
		{
			res=+1;
		}
		else
			res=0;
		return res;

	
	}
}
