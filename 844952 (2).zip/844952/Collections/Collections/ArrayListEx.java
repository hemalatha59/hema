import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
class CountrySorter
{
	public static List<String> sortCountries(List<String> l1)
	{
		
		
		Collections.sort(l1);
		return l1;
	}
}
public class ArrayListEx {

	public static void main(String[] args) {
		List<String> l1=new ArrayList<String>();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			l1.add(sc.next());
		}
		CountrySorter c=new CountrySorter();
		List<String> l2=CountrySorter.sortCountries(l1);
		//List<String> l2=c.getClass().getName().sortCountries(l1);
		System.out.println(l2);

	}
	
}
