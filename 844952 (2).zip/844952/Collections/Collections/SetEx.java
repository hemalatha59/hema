import java.util.Arrays;
import java.util.Collection;
//import java.util.HashMap;
//import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class SetEx {
		public static void main(String args[])
		{
			Map<String,Double> hm=new TreeMap<String,Double>();

			hm.put("Ram",10000.0);
			hm.put("Arun",35000.0);
			hm.put("Karuna",25000.0);
			hm.put("Srilatha",45000.0);
			hm.put("Ram",25000.0);
			System.out.println(hm);
			Set<String> s=hm.keySet();
			for(String e:s)
			{
				System.out.println(e);
			}
			
			Collection<Double> values=hm.values();
			for(Double val:values){
				System.out.println(val);
			}
			Double[] value= new Double[values.size()];
					Arrays.sort(value);
					System.out.println(value);
			Set <Entry<String,Double>> s2=hm.entrySet();
			for(Entry<String,Double> e1:s2)
			{
				System.out.println(e1.getKey()+" "+e1.getValue());
			}
		}
}
