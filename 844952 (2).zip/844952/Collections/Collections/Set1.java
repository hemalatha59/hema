import java.util.TreeSet;

public class Set1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> t=new TreeSet<String>();
			t.add("One");
			t.add("Two");
			t.add("first");
						System.out.println(t.pollFirst());
						System.out.println(t.pollLast());
						//System.out.println(t.headSet("T",true));
						//System.out.println(t.subSet("i", false, "t", true));
						System.out.println(t);
	}

}
