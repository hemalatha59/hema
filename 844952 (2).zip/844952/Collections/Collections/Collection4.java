import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Collection4 {
	public static int sumOfOddValues(Map<Integer, Integer> hm)
	{
		int sum=0;
		Set<Entry<Integer, Integer>> hm1=hm.entrySet();
				for(Entry<Integer, Integer> e:hm1)
				{
					if(e.getKey()%2!=0){
						sum=sum+e.getValue();
					}
				}
		return sum;
			}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,Integer> hm=new HashMap<Integer,Integer>();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			hm.put(sc.nextInt(),sc.nextInt());
		}
		int a= sumOfOddValues(hm);
		//System.out.println(sumOfOddValues());
		Set<Entry<Integer, Integer>> hm1=hm.entrySet();
		for(Entry<Integer, Integer> e:hm1)
		{
			System.out.println(e.getKey()+" "+e.getValue());
		}
		System.out.println(a);
	}

}
