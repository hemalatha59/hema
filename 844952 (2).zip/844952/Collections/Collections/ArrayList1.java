import java.util.ArrayList;
import java.util.Scanner;
class Employee {
	int id;
	String name;

	Employee(int id,String name) {
		this.id = id;
		this.name = name;
	}
	public String toString()
	{
		return this.id+" "+this.name;
	}
	
}

public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList l1=new ArrayList();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			Employee e=new Employee(sc.nextInt(),sc.next());
			l1.add(e);
				
		}
		//ArrayList a1=new ArrayList();
		
	System.out.println(l1);
		
	}

}
