-----------------------------------------------------------------
/*2. Create a class that can accept an array of String objects and  return them
 as a sorted List 

Class Name 		: ListManager
Method Name 		: getArrayList 
Method Description 	: Converts the String array to ArrayList and sorts it
Argument		: String []elements  
Return Type 		: List- ArrayList containing the elements of the String array in sorted order 
Logic 			: Load the elements in to an ArrayList and sort it. 

*/

import java.util.*;
class ListManager2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String[] s=new String[4];
		for(int i=0;i<s.length;i++){
			s[i]=sc.nextLine();}
		List<String> l1=Arrays.asList(s);
		getElements(l1);
		System.out.println(l1);
	}
	public static List<String> getElements(List<String> l1)
	{	
		//List<String> l3=new ArrayList<String>();
		Collections.sort(l1);
		return l1;
	}
}
