import java.sql.*;
public class Database {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
			String url="jdbc:mysql://localhost:3306/Mydb";
			String username="root";
			String password="Hema@2428";
			String sql1="create table emp(emp_id smallint not null primary key,emp_name varchar(100));";
			String sql2="insert into emp values('2','raj');";
			String sql3="select * from emp;";
			String sql4="insert into emp(emp_id,emp_name) values(?,?);";
			String sql5="delete from emp where emp_id=2;";
			String sql6="delete from emp where emp_id=?;";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);
		Statement st=con.createStatement();
		PreparedStatement pstmt=con.prepareStatement(sql6);
			//pstmt.setInt(1, 5);
			//pstmt.setString(2, "rgm");
			//pstmt.executeUpdate();
			//st.executeUpdate(sql1);
		pstmt.setInt(2,5);
			//System.out.println("Table created");
		pstmt.executeUpdate(sql5);
		System.out.println("Deleted");
			ResultSet rs=pstmt.executeQuery(sql3);
			while(rs.next())
			{
					System.out.println(rs.getInt(1)+" "+rs.getString(2));
			}
			pstmt.close();
			//st.close();
			con.close();
	}

}
