
public class Stud {

}
