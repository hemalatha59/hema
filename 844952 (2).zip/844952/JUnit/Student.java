package demo;

public class Student  {
int sid;
String nam;
public Student(int sid, String nam) {
	super();
	this.sid = sid;
	this.nam = nam;
}
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getNam() {
	return nam;
}
public void setNam(String nam) {
	this.nam = nam;
}
	
}