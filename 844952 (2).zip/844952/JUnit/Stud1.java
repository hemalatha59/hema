package demo;

import static org.junit.Assert.*;

import org.junit.Test;

public class Stud1 {
	Stu s1= new Stu();
	@Test
	public void test1() {
		 s1.setSid(1000);
		s1.setName("Shivani");
		assertEquals(1000,s1.getSid());
		assertEquals("Shivani",s1.getName());
	}

}
