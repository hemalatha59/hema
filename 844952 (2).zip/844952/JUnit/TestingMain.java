package demo;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import junit.framework.TestResult;
import junit.framework.TestSuite;

public class TestingMain {

	public static void main(String[] args)
	{
		Result res= JUnitCore.runClasses(Calculate.class);
		for(Failure fa:res.getFailures())
		{
			System.out.println("Fail: "+fa);
		}
		System.out.println("Success ??"+res.wasSuccessful());
		
		TestSuite suite=new TestSuite(AssertTest1.class,DivTest.class);
		TestResult result1=new TestResult();
		suite.run(result1);
		System.out.println("Number of test cases= "+result1.runCount());

	}

}
