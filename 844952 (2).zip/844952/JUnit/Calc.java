package demo;

public class Calc implements Calculator {
public int taxcal(int a){
	int sum=a*a;
	return sum;
}
}
