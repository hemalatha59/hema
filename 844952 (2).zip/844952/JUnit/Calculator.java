package demo;

public interface Calculator {

}