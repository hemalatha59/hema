package com.cts;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//@RequestParam -- receive value from jsp . It is like request.getparameter() method in servlets
@Controller
public class FormController {
	@RequestMapping(value="/checkaccount",method=RequestMethod.POST)
	public String display(@RequestParam("user1")String username, @RequestParam("pass")String password,Model m)
	{
		if(username.equals("hema"))
		{
			String msg="Hello"+username;
			//adding a msg to the model
			m.addAttribute("message",msg);
			return "successpage";//jsp file name
		}
		else
		{
			String msg="Sorry!Invalid"+username;
			m.addAttribute("meassage1",msg);
			return "errorpage";//jsp file name
		}
	}
}
