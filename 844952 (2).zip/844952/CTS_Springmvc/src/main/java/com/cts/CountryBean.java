package com.cts;

public class CountryBean {
String countryname;
String climate;

public CountryBean(String countryname, String climate) {
	super();
	this.countryname = countryname;
	this.climate = climate;
}

public void setCountryname(String countryname) {
	this.countryname = countryname;
}

public void setClimate(String climate) {
	this.climate = climate;
}

public String getCountryname() {
	return countryname;
}

public String getClimate() {
	return climate;
}

}
