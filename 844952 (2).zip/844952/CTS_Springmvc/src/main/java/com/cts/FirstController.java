package com.cts;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstController {
//similar to @Web-servlet
	@RequestMapping("/hdfclogin")
	public String display1()
	{
		//connecting to view layer
		return "callview";//jsp view file name
	}
	//sending data from controller to view
	@RequestMapping("/signin")
	//A model is a class which is implements  map interface that is used to stote attribute value
	public String display2(Model m)
	{
		m.addAttribute("myname", "Hemalatha");
		return "view12";
	}

} 
