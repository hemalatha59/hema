package com.cts;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("maincall")
public class FormMVCController {
	@RequestMapping("/callpage")
	public String disp(Model model)
	{
		FormBean res=new FormBean();
		Map<String,String> c1=new HashMap<String,String>();
		c1.put("US", "United States");
		c1.put("IN", "India");
		c1.put("SG", "Singapore");
		c1.put("AL", "Australia");
		//select option values sending to jsp
		model.addAttribute("countryopt", c1);
		model.addAttribute("result",res);
		return "FormLogin";

	}
	
	//@ModelAttribute--sending BEAN Form values to Jsp
	@RequestMapping("/valid")
	public String SubmitForm(@ModelAttribute("result12")FormBean res)
	{
		return "SuccessForm";
		
	}
	

}
