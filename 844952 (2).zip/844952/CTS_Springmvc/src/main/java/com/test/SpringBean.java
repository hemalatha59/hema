package com.test;

public class SpringBean {
	String name;

	
	public void setName(String name) {
		this.name = name;
	}

	public void display()
	{
		System.out.println("Welcome spring  "+name);
	}
	
}
