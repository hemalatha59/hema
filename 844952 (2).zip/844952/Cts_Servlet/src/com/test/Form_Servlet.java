package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Form_Servlet
 */
@WebServlet("/Form_Servlet")
public class Form_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Form_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("u1");
	String pwd=request.getParameter("p1");
	String gender=request.getParameter("r1");
	String[] lang=request.getParameterValues("c1");
	pw.println(" <h1>\n "+name+" \n "+pwd+"\n  "+gender);
	for(int i=0;i<lang.length;i++)
	{
		pw.println(" <h1> "+lang[i]);
	}
	String[] qual=request.getParameterValues("s1");
	for(int i=0;i<qual.length;i++)
	{
		pw.println("<h1>  "+qual[i]);
	}
	
	}

}
