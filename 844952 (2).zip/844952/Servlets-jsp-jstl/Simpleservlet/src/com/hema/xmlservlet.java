package com.hema;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class xmlservlet extends GenericServlet {
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//System.out.println("welcome");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		String fullname=request.getParameter("fullname");
		out.println("hello user.!" +  username);
		out.println("We know your full name is" + fullname);
		String profession=request.getParameter("prof");
		out.println("your profession is" + profession);
		//String skills=request.getParameter("skills");
		//out.println("ypu are skilled in"+ skills);
		String skills[] = request.getParameterValues("skills");
		out.println("you know "+ skills.length+ "skills" );
		for(int i=0;i<skills.length;i++) {
			out.println(skills[i]);
		}
	}

	
		
}

	


