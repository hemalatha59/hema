package com.test;

public class Bank {
	String name;
	String manager;
	Branch b1;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public Branch getB1() {
		return b1;
	}
	public void setB1(Branch b1) {
		this.b1 = b1;
	}
	
}
