package com.test;

import java.util.Iterator;
import java.util.List;

public class Vendor_Coll {
	int vid;
	String vname;
	List<String> cus_name;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public List<String> getCus_name() {
		return cus_name;
	}
	public void setCus_name(List<String> cus_name) {
		this.cus_name = cus_name;
	}
	public void display()
	{
		System.out.println(vid+" "+vname);
		System.out.println("Customers are:");
		Iterator<String> i=cus_name.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
