package com.test;

import java.util.Iterator;
import java.util.Set;

public class Vendor_Collection {
	int vid;
	String vname;
	Set<String> cus_name;
	public Vendor_Collection(int vid, String vname, Set<String> cus_name) {
		super();
		this.vid = vid;
		this.vname = vname;
		this.cus_name = cus_name;
	}
	public void display()
	{
		System.out.println("the data is:");
		System.out.println(vid+" "+vname);
		System.out.println("Customers are:");
		Iterator<String> i=cus_name.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
