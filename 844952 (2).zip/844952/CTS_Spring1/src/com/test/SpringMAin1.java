package com.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.Employee_JdbcTemplate1;

public class SpringMAin1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*ApplicationContext--Central interface to
		*provide configuration for an application
		*This is read only while the */
		
			/*FirstBean myBean=(FirstBean)beanFactory.getBean("bean1");	
			myBean.display();
			
			
			AbstractApplicationContext context=new AnnotationConfigApplicationContext(AnnoBean1.class);
			AnnoBean myBean1=(AnnoBean)context.getBean("SpringBean");
			myBean1.disp("Hema");
			
			EmployeeBean empBean=(EmployeeBean)beanFactory.getBean("emp");
			empBean.show();
			//Student s=(Student)beanFactory.getBean("stud");
			Student_Course sc=(Student_Course)beanFactory.getBean("c1");
			System.out.println(sc.getCid());
			System.out.println(sc.getCname());
			System.out.println(sc.getSid());
			System.out.println(sc.getName());
			
			
			
			UserProperties p=(UserProperties)beanFactory.getBean("prop1");
			System.out.println(p.getUser()+" "+p.getRole()+" "+p.getEmail());
			
			
			
			System.out.println("Ref tag(without autowiring)");
			Bank bank1=(Bank)beanFactory.getBean("bank_aw");
			System.out.println(bank1.getName());
			System.out.println(bank1.getManager());
			System.out.println(bank1.getB1().getCity());
			System.out.println(bank1.getB1().getState());
			
			
			System.out.println("No Ref tag(with autowiring : byName)");
			Bank bank2=(Bank)beanFactory.getBean("bank_aw");
			System.out.println(bank2.getName());
			System.out.println(bank2.getManager());
			System.out.println(bank2.getB1().getCity());
			System.out.println(bank2.getB1().getState());
			
			System.out.println("No Ref tag(with autowiring : byName)");
			EmployeeBean eb1=(EmployeeBean)beanFactory.getBean("myemp2");
			eb1.show();
			
			Bank_Autowire myBean31=(Bank_Autowire)beanFactory.getBean("anno1");
			System.out.println(myBean31.getBankname());
			System.out.println(myBean31.getMgrname());
			System.out.println(myBean31.getB20().getCity());
			System.out.println(myBean31.getB20().getState());
			
			
			System.out.println("Collection-setter injection:");
			Vendor_Coll v=(Vendor_Coll)beanFactory.getBean("l1");
			v.display();
			
			System.out.println("Collection-setter injection with ref tag:");
			Training_Coll tr2=(Training_Coll)beanFactory.getBean("tr1");
			tr2.display();
			
			System.out.println("Map-Collection-Setter injection::");
			Assessment_MapCollection m1=(Assessment_MapCollection)beanFactory.getBean("asmap1");
			m1.display();
	
			System.out.println("Map-Collection-constructor injection::");
			Vendor_Collection m2=(Vendor_Collection)beanFactory.getBean("setcol");
			m2	.display();*/
		ApplicationContext beanFactory=new ClassPathXmlApplicationContext("SpringConfig1.xml");
		//No xml file and no beab object class and seperate spring configuration class file
		SpringAnno_Component obj23=(SpringAnno_Component)beanFactory.getBean("SpringAnnoNew");
		System.out.println(obj23.training+" "+obj23.loc);
		
		
			Employee_JdbcTemplate1 s=(Employee_JdbcTemplate1)beanFactory.getBean("mydatabase");
			System.out.println("Spring+jdbc");
			List<Employee_Jdbc> e2=s.listemp();
			System.out.println("Eno  Name  Salary");
			for(Employee_Jdbc rec:e2)
			{
				System.out.println(rec.getEmp_no()+" ");
				System.out.println(rec.getEmp_name()+" ");
				System.out.println(rec.getSalary()+" ");
			}
	}

}
