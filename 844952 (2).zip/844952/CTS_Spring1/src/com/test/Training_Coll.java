package com.test;

import java.util.Iterator;
import java.util.List;

public class Training_Coll {
	int batchno;
	String projectname;
	List<Technology_Coll> tc1; //3rd paarty object
	public int getBatchno() {
		return batchno;
	}
	public void setBatchno(int batchno) {
		this.batchno = batchno;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public List<Technology_Coll> getTc1() {
		return tc1;
	}
	public void setTc1(List<Technology_Coll> tc1) {
		this.tc1 = tc1;
	}
	public void display()
	{
		System.out.println(batchno+" "+projectname);
		System.out.println("Tech traings   are:");
		Iterator<Technology_Coll> i=tc1.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
