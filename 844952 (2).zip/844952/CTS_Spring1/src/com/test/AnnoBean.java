package com.test;

public class AnnoBean {
	public void disp(String name)
	{
		System.out.println(name);
	}
}
