package com.cts;

public class EmployeeBean {

}
