package hema;

public abstract class AbbstractEx {
 int a;
 volatile Double d;
 synchronized Integer f;
 static abstract protected int e();
 static String b;
 transient int c;
 
}
