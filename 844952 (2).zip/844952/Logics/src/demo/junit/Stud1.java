package demo.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Stud1 {
	Student s1=new Student();

	@Test
	public void test12() {
		s1.setSno(1001);
		s1.setSname("Hema");
		assertEquals(1001,s1.getSno());
		assertEquals("Hema",s1.getSname());
	}

}
