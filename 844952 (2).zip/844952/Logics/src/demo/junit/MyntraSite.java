package demo.junit;
class herit
{
	void go() {
		System.out.println("Go() method");
	}
}
interface a
{
	void dis();
}
interface b

{

 void dis1();

}

interface c extends a,b

{

 void dis2();

}

// first extends then implements

public class MyntraSite extends herit implements Shopping,a,b{
 @Override
 public void addItem() {
	 System.out.println("Add item interface method");
 }
 @Override

 public String view(String msg) {
 return msg;

 }
 @Override

 public void dummy() {
 }
 //class method
 public void msg() {
	 System.out.println("Dont sleep");
 }
 public static void main(String[] args) {
	 MyntraSite m1=new MyntraSite();
	 m1.addItem();
	 System.out.println(m1.view("Shopping done"));
	 m1.go();
	 m1.dis1();
	 m1.dis();
	 //Runtime polymorphism 
	 a obj1=new MyntraSite();
	 obj1.dis();
	 //Upcasting
	 ((MyntraSite)obj1).msg();
 }
@Override
public void dis1() {
	System.out.println("hi");
}
@Override
public void dis() {

	System.out.println("bye");
}
}





