package demo.junit;

public interface Shopping {
	public void addItem();
	public String view(String msg);
	void dummy();
}
