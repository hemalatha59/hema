package demo.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Asser1junit {

	@Test
	public void test123() {
		String o1="junit";
		String o2="junit";	
		String o3=new String("test");
		String o4="test";
		String o5=null;
		int var1=1;
		int var2=2;
		int[] a1= {1,2,3,4};
		int[] a2= {1,2,3,4};
		assertEquals(o3,o4);
		assertEquals(o1,o2);
		//check if two object references point to the same object
		//assertSame(o3,o4);
		assertSame(o1,o2);
		//check if two obj ref not point to the same ref
		assertNotSame(o3,o4);
		//check that an obj isnt null
		assertNotNull(o1);
		//check that an obj is null
		assertNull(o5);
		//check that a condition is true
		assertTrue(var1<var2);
		//check that a condition is false
		assertFalse(var1>var2);
		//check whether two arrays are equal to each other
		assertArrayEquals(a1,a2);
	}

}
