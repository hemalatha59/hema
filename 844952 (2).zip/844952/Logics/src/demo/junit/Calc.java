package demo.junit;

public class Calc {
	public int taxcal(int a)
	{
		int sum=a*a;
		return sum;
	}
}
