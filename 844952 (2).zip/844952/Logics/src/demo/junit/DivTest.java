package demo.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class DivTest {
	Division d1=new Division(10,2);
	Division d2=new Division(10,0);
	@Test(expected=ArithmeticException.class)
	public void test() {
		System.out.println("First test case");
		assertEquals(5,d1.division());
		assertEquals(1,d2.division());
	}
	
	
	@Test(expected=ArithmeticException.class)
	public void test1()
	{
		System.out.println("second test case");
		assertEquals(5,d2.division());
	}
	@Test(expected=ArithmeticException.class)
	public void test2()
	{
		//throw new NullPointerException();//Fails
		throw new ArithmeticException();//Success
	}

}
