package hema;

import java.util.ArrayList;
import java.util.List;

public class Generics1 {
	public static void print(List<?> obj)
	{
		for(Object ele:obj)
		{
			System.out.println(ele);
		}
	}
	public static void main(String[] args) {
		 
		ArrayList a1=new ArrayList();
		a1.add("java 1.0 to 5.0");
		a1.add(45.89);
		//non-generic typecasting required
		String s1=(String)a1.get(0);
		System.out.println("Non generic:"+s1);
		
		ArrayList<Integer> a2=new ArrayList<Integer>();
		ArrayList<Integer> a3=new ArrayList<>();
		a2.add(3);
		a2.add(6);
		a2.add(9);
		a2.add(12);
		System.out.println(a2);
		Integer i2=a2.get(2);//generic - no type casting required
		print(a2);
		ArrayList<String> a4=new ArrayList<String>();
		a4.add("hema");
		a4.add("swarna");
		a4.add("lohi");
		print(a4);
		


	}

}
