package hema;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ArrayList2 {
	private static int DEFAULT_CAPACITY=10;
	private static int minCapacity;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String args[])
	{
		ArrayList<Integer> l=new ArrayList<Integer>(DEFAULT_CAPACITY);
	      System.out.println(Math.max(DEFAULT_CAPACITY,minCapacity));
	      l.ensureCapacity(12);
	      System.out.println(l);
		l.add(12);
		l.add(88);
		l.add(78);
		l.add(77);
		l.add(12);
		l.add(88);
		l.add(78);
		l.add(77);
		l.add(12);
		l.add(88);
		l.add(78);
		l.add(77);
		l.add(88);
		l.add(78);
		l.add(77);
		l.add(12);
		l.add(88);
		l.add(78);
		l.add(77);
		l.add(12);
		l.add(88);
		l.add(78);
		l.add(77);
		//l.set(2, 24);
		System.out.println(l.size());
		l.add(22);
		System.out.println(l);
	
	}
}
