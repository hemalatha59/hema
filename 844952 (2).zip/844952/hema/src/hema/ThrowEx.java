package hema;
public class ThrowEx {
	public static void demo() throws Exception
	{
		System.out.println("This id demo()");
		try {
		//	int[] arr = new int[5];
		//	System.out.println(arr[9]);
		throw new ArrayIndexOutOfBoundsException("Salary Negative");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			//e.printStackTrace();
			System.out.println("fdfdf"+e.getMessage());
			throw new Exception("Over");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		ThrowEx.demo();
		}
		catch(Exception e) {
		//	e.printStackTrace();
			System.out.println("Res "+e.getMessage());
			System.out.println("End");
		}
		}

}
