package hema;

public class Person extends Per {

	public Person() {
		super();
	}

}