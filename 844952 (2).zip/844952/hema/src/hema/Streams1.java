package hema;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/*
 * Java8, the stream API is used to process collections of objects
 * --Designed for lamda expressions
 * --Do not support indexed access
 * --Can easily be outputted as arrays or lists
 */
class Product
{
	String pname;
	float price;
	public Product(String pname, float price) {
		super();
		this.pname = pname;
		this.price = price;
	}
	
}
public class Streams1 {

	public static void main(String[] args) {
		List<Product> pr1=new ArrayList<Product>();
		pr1.add(new Product("HP",25000f));
		pr1.add(new Product("Dell",30000f));
		pr1.add(new Product("Lenovo",28000f));
		List<Float> pr2=new ArrayList<Float>();
		for(Product product:pr1)
		{
			//filtering data of list
			if(product.price<30000) {
			pr2.add(product.price);
			//adding price to a pr2
			}
		}
		System.out.println("After filter:"+pr2);
		//Stream API
		List<Float> f1=pr1.stream()
				.filter(e->e.price<30000)//filtering data
				.map(e->e.price)
				.collect(Collectors.toList());
		System.out.println("Stream Filter:"+f1);
		
		//count the num of products based on the filter
		long count=pr1.stream()
				.filter(ps->ps.price<30000)
				.count();
		System.out.println("Stream Filter Count:"+count);
		pr1.stream()
		.filter(ps1->ps1.price<30000)
		.forEach(ps2->System.out.println("<Than 30000 PName:"+ps2.pname));
	}

}
