package hema;

public class Per {

	public Per() {
		super();
	}

}