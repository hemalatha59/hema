package hema;
interface a
{
 void happy();
}
public class xyz implements a {
public void happy() {}
}
