package hema;

public interface InterfaceEx {
int a;//int a; should be initialized bcz by default members and methods are public static &final
//public static final int a=2;==>this is the implicit declaration
volatile int b;
synchronized double d;
Double d1;
double d2;
static String s1;
}
