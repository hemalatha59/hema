package hema;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class collection10 {

	public static void main(String[] args) {
		HashSet<Object> h=new HashSet<Object>();
		//Set s=new HashSet();
		h.add(244);
		h.add(new Integer("2"));
		h.add(new Integer("4"));
		h.add(new Integer("2"));
		h.add(new Float("43.2654"));
		h.add(new String("Hem"));//NumberFormatException
		System.out.println("The hashset contains"+h);
		System.out.println("The hashset size"+h.size());
		System.out.println("The hashset is empty?"+h.isEmpty());
		Iterator<Object> itr=h.iterator();
		while(itr.hasNext())
		{
			System.out.println("The hashset contains"+itr.next());
		}
		List<Object> l=new ArrayList<Object>();
		l.add("4");
		l.add(25);
		l.add(7);
		l.add(4);
		l.add("devi");
		l.add(36.98);
		System.out.println("ArrayList:"+l);
		for(Object a:l)
		{
			System.out.println(a);
		}
	}

}
