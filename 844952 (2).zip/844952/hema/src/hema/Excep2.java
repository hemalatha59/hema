package hema;

public class Excep2 {
	public static void main(String args[])
	{
		int d,a;
		try
		{
			d=0;
			a=42/d;
			System.out.println("\n\tThe res is:"+a);
		}
		catch(Throwable e) //catch(Exception e) catch(ArithmeticException e)
		{
			System.out.println("\n\tDivisible by zero");
			System.out.println("\n\tException:"+e);//exception name and message
			System.out.println("\n\tException:"+e.getMessage());//exception message
			e.printStackTrace();
		}
		//code enclosed within a finally block will alwayss be executed(Whethe or not an exception occurs.
		finally {
			System.out.println("\n\tAfter catch block, finally block");
		}
	}
}
