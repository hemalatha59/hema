package hema;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Year;
import java.util.Date;

public class Date1 {

	public static void main(String[] args) throws Exception {
		Date date=new Date();
		System.out.println("Date class "+date.toString());
		Date dnow=new Date();
		SimpleDateFormat sdf1=new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
		System.out.println("CurrentDate:"+sdf1.format(dnow));
		LocalDate date1=LocalDate.now();
		LocalDate yesterday=date1.minusDays(1);
		System.out.println("Today date:"+date1);
		System.out.println("Today date:"+yesterday);

		 LocalTime time = LocalTime.now();



		 System.out.println("Current Time: "+time);


		 Year y = Year.of(2019);
		 LocalDate l = y.atDay(90);

		 System.out.println("2019 : (90th day): "+l);
		 //parsing String to Date object
		 
		 String dateInString ="15-10-2015 10:20:56";
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyy hh:mm:ss");
		 Date date4=sdf.parse(dateInString);
		 System.out.println("String to Date: "+date4);		
	}

}
