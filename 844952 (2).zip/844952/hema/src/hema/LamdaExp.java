package hema;

import java.util.ArrayList;
import java.util.List;

public class LamdaExp {
	/*
	 * --If we want to declare and define methods in an interface then we can go for interface
	 * --Lamda expressions basically express instances of functional interface
	 * --(An Interface with single abstract method is called functional interface. An example is java.lang.Runnable).
	 * --Lamda expressions implement the only abstract function and therefore implement functional interfaces
	 * (argument-list) -> {body}
	 */
	interface building
	{
		public void room();
		//public void room1();
		default void dummy() //explicitly defining default
		{
			System.out.println("Non abstract interface method");
		}
	}
	interface My1
	{
		double getPi();
	}
	interface calc
	{
		public int add(int a,int b)
		;
		default float sub(int a,float b)
		{
			return a-b;
		}
	}
	public static void main(String args[])
	{
		//without lamda using ananymous class
		//no implements
		building d=new building()
				{
					public void room()
					{
						System.out.println("3500sqft");
					}
				};
				building b2=new building()
						{
							public void room()
							{
								System.out.println("2355sqft");
							}
						};
						d.room();
						b2.room();
						//jdk1.8 and above
						//with lamda but zero arguments
						//no seperate .class file for instance
						building d2=()->
						{
							System.out.println("Lamda-4000sqft");
						};
						d2.room();
						My1 m1=()->3*3.1415;
							System.out.println("VAlue of Pi:"+m1.getPi());
							
						
						//Multiple parameters in lambda expression
						//without return keyword
						//datatypes are optional
						//calc ad1=(a,b)->(a+b);//valid
						calc ad1=(int a,int b)->(a+b);//valid
						System.out.println("Add:"+ad1.add(10, 20));
						System.out.println("Sub:"+ad1.sub(34, 4.0f));
						List<String> dept=new ArrayList<String>();
						dept.add("Finance");
						dept.add("Insurance");

						dept.add("Admin");
						//lamda for eachloop
						dept.forEach
						(
								(n)->System.out.println(n) //no need of semicolon
						);
						
	}
}
