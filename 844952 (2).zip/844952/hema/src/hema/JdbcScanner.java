package hema;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcScanner 
{
	public static void main(String args[]) throws SQLException
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Please Enter Emp name:");
		String catName = s.nextLine();
		System.out.println("Please Enter Emp salary:");

		int sal = s.nextInt();
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
		    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Hema@2428"); 
		    String sql="insert into emp1(Eno,Ename,Salary) values(102, ?, ?)";
		    stmt = conn.prepareStatement(sql);
		    stmt.setString(1, catName);
		    stmt.setInt(2,sal);
		    stmt.execute();
		}
		catch (SQLException se)
		{
		    System.out.println(se.getMessage());
		}
		finally 
		{
		    conn.close();
		}
		
	}
}
	
	

