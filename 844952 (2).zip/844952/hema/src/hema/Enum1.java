package hema;
//enum is the  group of constants by using we can retrieve the names as such than the assigned value so there is diff b/w enum retrieve and variable retrieve
//to define our own datatypes and if we want retrieve the name of the enum then we can go vfor enum
/*
 * --Enum declaration can be done outside a class
 * or inside a class but not inside a method
 * --enum constant is always implicitly
 * public static final. Since it is static, we can access it by using enum Name
 * -- enum cant be used to create objects, and it cant be extend other classes
 */

enum dept
{
	Insurance,Training,Pitsop,Network;
	String display()
	{
		String msg="You are working in "+this+"dept";
		System.out.println("Inside enum:"+msg);
		return msg;
	}
}
public class Enum1 {
	enum month
	{
		January,March,April, February
	}
	public static void main(String[] args) {
		System.out.println("Enum:"+dept.Insurance);//enumname.constant
		dept c1[]=dept.values();
		for(dept j1:c1)
		{
			System.out.println("Dept Datatypes : "+j1);
			
		}
		System.out.println("Enum method:"+dept.Pitsop.display());
		month m1;
		m1=month.January;
		switch(m1)
		{
		case February:
			System.out.println("Warn");
			break;
		case January:
			System.out.println("Winter");
			break;
			default:
				System.out.println("I dont know");
				break;
		}
		final String name="Hema";
		//name="Latha"; //cannot be modified or altered
		System.out.println(name);
	}

}
