package hema;

public interface Age {

}