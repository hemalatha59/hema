/* 1.Create a class with a method which can remove all the elements from a list
 other than the collection of elements specified.

Class Name :ListManager

Method Name: removeElements
 
Method Description : Remove all the elements from a list other than the 
collection of elements specified. 

Argument: List<String> list1, List<String> list2;

Return Type : List- ArrayList contains the resulting List after the
 removal process.

Logic : Accept two List objects list1 and list2 and remove all the elements
 from list 1 other than the elements contained in list2.
This should be done in single step process without using loop.
*/
import java.util.*;
class ListManager
{
	public static void main(String args[])
	{
		List<String> l1=new ArrayList<String>();
		List<String> l2=new ArrayList<String>();
		l1.add("One");
		l1.add("Two");
		l1.add("Three");
		l1.add("Four");
		l1.add("Five");
		l2.add("One");
		l2.add("Two");
		l2.add("Three");
		l2.add("Six");
		l2.add("Ten");
		System.out.println(l1);
		System.out.println(l2);
		
		removeElements(l1,l2);
		System.out.println(l1);
	}
	public static List<String> removeElements(List<String> l1,List<String> l2)
	{	
		//List<String> l3=new ArrayList<String>();
		l1.retainAll(l2);
		return l1;
	}
}
