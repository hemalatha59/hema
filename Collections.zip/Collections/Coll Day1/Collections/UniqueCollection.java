/* 3. Create a method that returns collection that contain only unique String object in the sorted order. 

Class Name 		: UniqueCollection 
Method Name 		: getCollection 
Method Description 	: Accepts a String array and load the elements into a collection that can hold only unique element in a sorted order. 
Argument		: String []elements 
Return Type		: Interface type of the Collection used
Logic			: Accept a String array, convert it to a collection of unique elements stored in sorted order and return the results. 
*/

import java.util.*;
class UniqueCollection
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String[] s=new String[4];
		for(int i=0;i<s.length;i++){
			s[i]=sc.nextLine();}
		Set<String> s1=new TreeSet<String>(Arrays.asList(s));
		getCollections(s1);
		System.out.println(s1);
	}
	public static Set<String> getCollections(Set<String> s1)
	{	
		//List<String> l3=new ArrayList<String>();
		//Collections.sort(s1);
		return s1;
	}
}
