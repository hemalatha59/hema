function validateform()
{  
	var x = document.forms["form1"]["txt_fname"].value;
	  if (x == "") {
	    alert("Name must be filled out");
	    return false;
	     }
	    var email = document.forms["form1"]["txt_email"].value;
	     if (email == "") {
		    alert("Email must be filled out");
		    return false;
	        }
		 
		  var username = document.forms["form1"]["txt_username"].value;
		  if (username == "") {
		    alert("Username must be filled out");
		    return false;
		  }
		  var password = document.forms["form1"]["txt_password"].value;
		  if (password == "") {
		    alert("Password must be filled out");
		    return false;
		  }
		  var age = document.forms["form1"]["txt_age"].value;
		  if (age == "") {
		    alert("age must be filled out");
		    return false;
		  }
		  var city = document.forms["form1"]["txt_city"].value;
		  if (city == "") {
		    alert("city must be filled out");
		    return false;
		  }
} 