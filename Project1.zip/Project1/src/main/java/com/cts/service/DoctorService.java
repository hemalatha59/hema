package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.dao.DoctorDAo;
import com.cts.pojo.Appointment;
import com.cts.pojo.Doctor;
import com.cts.pojo.Patient;
@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class DoctorService {
	
	@Autowired
	private DoctorDAo doctorDao1;
	
	public void createDoctor(Doctor doctor) 
	{	
		doctorDao1.createDoctor(doctor);	
	}
	
	@Transactional
	public List<Doctor> getdocs() 
	{
		
		return doctorDao1.getDoctor();
	}
	
	@Transactional
	public void deletedocs(long theId)
	{
		doctorDao1.deleteDoc(theId);
	}
	 //call controller
    public boolean checkLogin(String userName, String userPassword){
        System.out.println("In Service class...Check Login");
        return doctorDao1.checkLogin(userName, userPassword);
 }
    
    public void createPatient(Patient patient) 
	{	
		doctorDao1.createPatient(patient);
		
	}
	
	@Transactional
	public List<Patient> getpat() 
	{
		
		return doctorDao1.getPatient();
	}
	 //call controller
    public boolean checkLogin1(String userName, String userPassword){
        System.out.println("In Service class...Check Login");
        return doctorDao1.checkLogin1(userName, userPassword);
 }
    @Transactional
	public void deletepats(long theId)
	{
		doctorDao1.deletePat(theId);
	}
    
    public void createAppointment(Appointment appointment) 
  	{	
  		doctorDao1.createAppointment(appointment);	
  	}
  	
  	@Transactional
  	public List<Appointment> getappoint() 
  	{
  		
  		return doctorDao1.getAppointment();
  	}
  	 @Transactional
 	public void deleteappoints(long theId)
 	{
 		doctorDao1.deleteAppoint(theId);
 	}
     
  	
}
