package com.cts.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name = "newdoctor")
public class Doctor {
	//@NotBlank
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	//@NotEmpty(message = "Please enter name")
	@Column
	private String firstname;
	
	@Column
	private String lastname;
	@Column
	private int age;
	//@NotEmpty(message = "Please enter mobile number")
	
	@Column
	private long phone;
	//@Email(message = "Please enter valid email address")
//@Pattern(regexp=".+@.+\\..+", message="Please enter valid email address")
	//@NotEmpty(message = "Please enter email id")
	@Column
	private String email;
	//@NotEmpty(message = "Please enter address")
	@Column
	private String address;
	//@NotEmpty(message = "Please enter city")
	@Column
	private String city;
	@Column
	private String country;
	//@NotEmpty(message = "Please enter hospital name")
	@Column
	private String hospitalname;

	@Column
	private String specialist;
	//@NotEmpty(message = "Please enter username")
	@Column
	private String username;
	//@NotEmpty(message = "Please enter password")
	@Column
	private String password;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getHospitalname() {
		return hospitalname;
	}
	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	 
	


}
