package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.pojo.Appointment;
import com.cts.pojo.Doctor;
import com.cts.pojo.Patient;
import com.cts.service.DoctorService;

@Controller
public class DoctorController {
	@Autowired
	private DoctorService doctorService1;
	@RequestMapping("welcome")
	public String display() 
	{	
		//employee attribute==modelattribute in register.jsp

		return "welcome";//register.jsp==form action=register		
	}
	@RequestMapping("admin")
	public String display1() 
	{	
		//employee attribute==modelattribute in register.jsp

		return "admin";//register.jsp==form action=register		
	}
	@RequestMapping("callproj")
	public String createUser1(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("doctor",new Doctor());
		return "doctor-registerform";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "doctor-registerform", method = RequestMethod.POST)
	public String createUser(@ModelAttribute Doctor doctor1,Model m)
	{
		doctorService1.createDoctor(doctor1);//save(employee)
		 return "redirect:/login"; //redirect to request pattern::view
	       }
	
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView viewLogin(@ModelAttribute Doctor doctor) {
		return new ModelAndView("login");//login.jsp
	}


	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute Doctor doctor) 
	{
		boolean emp = doctorService1.checkLogin(doctor.getUsername(),doctor.getPassword());
		ModelAndView model = null;
		if (emp) 
		{
			model = new ModelAndView("loginsuccess");//loginsuccess.jsp
			model.addObject("emp", doctor.getUsername());//access in jsp
			
		} else {
			model = new ModelAndView("login");//login.jsp
			model.addObject("result", "Invalid Username or Password!!");
		}
		return model;
	}
	
	
	//selection
	@RequestMapping(value = "view1", method = RequestMethod.GET)
	public String view1(@ModelAttribute Doctor doctor1,Model m)
	{
		List<Doctor> obj=doctorService1.getdocs();
		m.addAttribute("docs1",obj);//emps can beaccessin ViewEmp.jsp
			return "viewDoc";//ViewEmp.jsp
	}
		@RequestMapping(value = "view", method = RequestMethod.GET)
		public String view(@ModelAttribute Doctor doctor1,Model m)
		{
			List<Doctor> obj=doctorService1.getdocs();
			m.addAttribute("docs",obj);//emps can beaccessin ViewEmp.jsp
				return "adminDoc";//ViewEmp.jsp
		}
		
	    
	   
		//deletion
	    @RequestMapping(value="/deletedocs/{delno}",method = RequestMethod.GET)    
	    public String delemp(
	    		@PathVariable 
	    		int delno)
	    {    
	        doctorService1.deletedocs(delno);
	        return "redirect:/view"; //call req pattern /view
	    } 
	   
	@RequestMapping("register1")
	public String createUser2(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("patient",new Patient());
		return "patient-registerform";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "patient-registerform", method = RequestMethod.POST)
	public String createUser(@ModelAttribute Patient patient1,Model m)
	{
		doctorService1.createPatient(patient1);//save(employee)
		 return "redirect:/login1"; //redirect to request pattern::view
	       }
	@RequestMapping(value = "login1", method = RequestMethod.GET)
	public ModelAndView viewLogin1(@ModelAttribute Patient patient) {
		return new ModelAndView("login1");//login.jsp
	}


	@RequestMapping(value = "login1", method = RequestMethod.POST)
	public ModelAndView processLogin1(@ModelAttribute Patient patient) 
	{
		boolean emp = doctorService1.checkLogin1(patient.getUsername(),patient.getPassword());
		ModelAndView model = null;
		if (emp) 
		{
			model = new ModelAndView("loginsuccess1");//loginsuccess.jsp
			model.addObject("emp", patient.getUsername());//access in jsp
			
		} else {
			model = new ModelAndView("login1");//login.jsp
			model.addObject("result", "Invalid Username or Password!!");
		}
		return model;
	}
	 @RequestMapping(value = "patview", method = RequestMethod.GET)
		public String view2(@ModelAttribute Patient patient1,Model m)
		{
			List<Patient> obj=doctorService1.getpat();
			m.addAttribute("pats",obj);//emps can beaccessin ViewEmp.jsp
				return "adminPat";//ViewEmp.jsp
		}
	//deletion
	    @RequestMapping(value="/deletepats/{delno}",method = RequestMethod.GET)    
	    public String delpat(
	    		@PathVariable 
	    		int delno)
	    {    
	        doctorService1.deletepats(delno);
	        return "redirect:/patview"; //call req pattern /view
	    }
	    
	    
	    
	@RequestMapping(value = "admin", method = RequestMethod.GET)
	public ModelAndView viewLogin2(@ModelAttribute Patient patient) {
		return new ModelAndView("admin");//login.jsp
	}

	@RequestMapping(value = "admin", method = RequestMethod.POST)
	public ModelAndView processLogin2(@ModelAttribute Patient patient)
	{
	//boolean emp = employeeService1.checkLogin(employee.getUsername(),employee.getPassword());
	ModelAndView model = null;
	if (patient.getUsername().equals("admin")&& patient.getPassword().equals("1234"))
	{
	model = new ModelAndView("adminview");//loginsuccess.jsp
	model.addObject("emp", patient.getUsername());//access in jsp

	} else {
	model = new ModelAndView("admin");//login.jsp
	model.addObject("result", "Invalid Username or Password!!");
	}
	return model;
	}
	
	@RequestMapping("appointment")
	public String createForm1(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("appointment",new Appointment());
		return "appointment";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "appointment", method = RequestMethod.POST)
	public String createForm(@ModelAttribute Appointment appointment1,Model m)
	{
		doctorService1.createAppointment(appointment1);//save(employee)
		 return "redirect:/login"; //redirect to request pattern::view
	       }
	
	 @RequestMapping(value = "appointview", method = RequestMethod.GET)
		public String view3(@ModelAttribute Appointment appointment1,Model m)
		{
			List<Appointment> obj=doctorService1.getappoint();
			m.addAttribute("appoint",obj);//emps can beaccessin ViewEmp.jsp
				return "adminAppoint";//ViewEmp.jsp
		}
	//deletion
	    @RequestMapping(value="/deleteappoints/{delno}",method = RequestMethod.GET)    
	    public String delappoint(
	    		@PathVariable 
	    		int delno)
	    {    
	        doctorService1.deleteappoints(delno);
	        return "redirect:/appointview"; //call req pattern /view
	    }
}
